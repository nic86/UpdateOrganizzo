<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */

$languageStrings = [
	'OSSMail' => 'Meine E-Mailbox',
	'ERR_NO_MODULE_IS_INACTIVE' => '"My mailbox" module is inactive, it should be enabled before configuration.'
];

$jsLanguageStrings = [
	'JS_ERROR_EMPTY' => 'Alle Felder müssen ausgefüllt werden',
];
