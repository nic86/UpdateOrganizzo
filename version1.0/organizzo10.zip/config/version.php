<?php
return [
	'appVersion' => '1.0.000',
	'patchVersion' => '2017.09.04',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.34',
	'lib_PHPExcel' => '0.0.0',
	'lib_AJAXChat' => '0.0.2',
	'lib_gantt' => '0.0.0',
];
