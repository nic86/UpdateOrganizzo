<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	// Auto refresh reminders in header
	'AUTO_REFRESH_REMINDERS' => true, // Boolean
	// Auto mark notifications as readed after send emails to users
	'AUTO_MARK_NOTIFICATIONS_READ_AFTER_EMAIL_SEND' => false, // Boolean
];
