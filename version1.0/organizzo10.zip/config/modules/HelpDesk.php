<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	// Check if account exists
	'CHECK_ACCOUNT_EXISTS' => false,
	// Check if service contracts exists
	'CHECK_SERVICE_CONTRACTS_EXISTS' => false,
	'HIDE_SUMMARY_PRODUCTS_SERVICES' => false,
	'DEFAULT_VIEW_RECORD' => 'LBL_RECORD_PREVIEW',
];
