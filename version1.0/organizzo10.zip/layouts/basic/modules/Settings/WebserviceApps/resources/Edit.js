/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
Vtiger_Edit_Js('Settings_WebserviceApps_Edit_Js', {}, {
		
})
