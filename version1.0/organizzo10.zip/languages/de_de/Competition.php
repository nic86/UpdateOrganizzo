<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Competition' => 'Konkurrenz',
	'SINGLE_Competition' => 'Konkurrenz',
	//BLOCKS
	'LBL_COMPETITION_INFORMATION' => 'Informationen',
	'LBL_CUSTOM_INFORMATION' => 'System Information',
	'LBL_DESCRIPTION_INFORMATION' => 'Details',
	//FIELDS
	'LBL_SUBJECT' => 'Bezeichnung',
	'LBL_NUMBER' => 'Nummer',
	'LBL_CLOSED_TIME' => 'Geschlossen am',
	'LBL_VAT_ID' => 'MwSt',
];
