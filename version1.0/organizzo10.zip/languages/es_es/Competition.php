<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Competition' => 'Competencia',
	'SINGLE_Competition' => 'Competidor',
	//BLOCKS
	'LBL_COMPETITION_INFORMATION' => 'Información sobre el Competidor',
	'LBL_CUSTOM_INFORMATION' => 'Información adicional',
	'LBL_DESCRIPTION_INFORMATION' => 'Descripción',
	//FIELDS
	'LBL_SUBJECT' => 'Nombre',
	'LBL_NUMBER' => 'ID',
	'LBL_CLOSED_TIME' => 'Fecha de cierre',
	'LBL_VAT_ID' => 'ID Impuesto',
];
